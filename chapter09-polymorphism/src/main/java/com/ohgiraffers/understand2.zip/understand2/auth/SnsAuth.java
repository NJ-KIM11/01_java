package main.java.com.ohgiraffers.understand2.auth;

import main.java.com.ohgiraffers.understand2.dto.MemberDTO;

public interface SnsAuth {

    boolean login(MemberDTO member);


}
